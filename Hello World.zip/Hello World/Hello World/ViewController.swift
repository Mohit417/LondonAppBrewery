//
//  ViewController.swift
//  Hello World
//
//  Created by Mohit Katyal on 5/31/19.
//  Copyright © 2019 SWAYD. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}

