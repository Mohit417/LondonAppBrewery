//
//  SelfDrivingCar.swift
//  Classes and Objects
//
//  Created by Mohit Katyal on 6/22/19.
//  Copyright © 2019 SWAYD. All rights reserved.
//

import Foundation

class SelfDrivingCar : Car {
    
    var destination = "1 Infinite Loop"
    
    override func drive() {
        super.drive()
        
        print("driving towards " + destination)
    }
}
