//
//  main.swift
//  Classes and Objects
//
//  Created by Mohit Katyal on 6/22/19.
//  Copyright © 2019 SWAYD. All rights reserved.
//

import Foundation

let myCar = Car(colorOfCar: "black")

let hisCar = Car()

let selfDrivingCar = SelfDrivingCar()

print(myCar.color)
print(myCar.numberOfSeats)
print(myCar.typeOfCar)
print()
print(hisCar.color)
print(hisCar.numberOfSeats)
print(hisCar.typeOfCar)
print()
print(selfDrivingCar.color)
print(selfDrivingCar.numberOfSeats)
print(selfDrivingCar.typeOfCar)
selfDrivingCar.drive()

myCar.drive()


