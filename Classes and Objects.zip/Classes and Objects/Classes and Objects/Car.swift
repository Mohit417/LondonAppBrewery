//
//  Car.swift
//  Classes and Objects
//
//  Created by Mohit Katyal on 6/22/19.
//  Copyright © 2019 SWAYD. All rights reserved.
//

import Foundation

enum CarType {
    case Toyota
    case Honda
    case Mercedes
}

class Car {
    
    var color = "Red"
    var numberOfSeats: Int = 2
    var typeOfCar: CarType = .Honda
    
    init(){
       
    }
    
    convenience init(colorOfCar customerColor: String){
        self.init()
        color = customerColor
    }
    
    func drive(){
        print("We're driving!")
    }
}
