
import UIKit

var monsterHealth = 19

monsterHealth = monsterHealth + 22

print(monsterHealth)

print("Hello World!")


