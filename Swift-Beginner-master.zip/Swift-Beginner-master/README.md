# Swift-Beginner
Completed Swift Playground files for Module 7 of the London App Brewery Online iOS 10 /Swift 3 App Development course. 

[online.londonappbrewery.com](http://online.londonappbrewery.com)

Copyright © London App Brewery
