import UIKit

var myAge : Int = 20

myAge = 21

print(myAge)

let myName : String = "Mohit"

let myAgeInTenYears = myAge + 10

let mySurname : String = "Katyal"

let myFullName = "\(myName) \(mySurname)"

let myDetails = "\(myFullName), \(myAge)"

let wholeNumbers : Int = 32

let text: String = "abc"

let booleans : Bool = true

let floatingPointNumber : Float = 1.3

let double : Double = 3.13158123
